from setuptools import setup  # type: ignore

setup(
    include_package_data=True,
)
