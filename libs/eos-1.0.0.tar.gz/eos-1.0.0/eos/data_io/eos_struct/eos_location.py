from pydantic import BaseModel, ConfigDict, field_serializer
from ordered_set import OrderedSet
from zoneinfo import ZoneInfo
from .eos_time import timezones

LocationCat = OrderedSet(
    [
        "jiangyin",
        "shanghai",
        "anting",
        "unknown",
    ]
)


class EosLocation(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    abbr: str
    name: str
    cname: str
    tz: ZoneInfo

    @field_serializer('tz')
    def serialize_tz(self, tz: ZoneInfo, _info):
        return tz.key


locations = [
    EosLocation(
        abbr="jy",
        name="Jiangyin",
        cname="江阴",
        tz=timezones["sh"],
    ),
    EosLocation(
        abbr="hq",
        name="Hongqiao",
        cname="虹桥",
        tz=timezones["sh"],
    ),
    EosLocation(
        abbr="sh",
        name="Shanghai",
        cname="上海",
        tz=timezones["sh"],
    ),
    EosLocation(
        abbr="at",
        name="Anting",
        cname="安亭",
        tz=timezones["sh"],
    ),
    EosLocation(
        abbr="sp",
        name="Sao_Paulo",
        cname="圣保罗",
        tz=timezones["sp"],
    ),
    EosLocation(
        abbr="la",
        name="Los_Angeles",
        cname="洛杉矶",
        tz=timezones["la"],
    ),
    EosLocation(
        abbr="ny",
        name="New_York",
        cname="纽约",
        tz=timezones["ny"],
    ),
    EosLocation(
        abbr="xj",
        name="Urumqi",
        cname="乌鲁木齐",
        tz=timezones["xj"],
    ),
    EosLocation(
        abbr="bl",
        name="Berlin",
        cname="柏林",
        tz=timezones["bl"],
    ),
    EosLocation(
        abbr="ld",
        name="London",
        cname="伦敦",
        tz=timezones["ld"],
    ),
    EosLocation(
        abbr="sy",
        name="Sydney",
        cname="悉尼",
        tz=timezones["sy"],
    ),
    EosLocation(
        abbr="jp",
        name="Tokyo",
        cname="东京",
        tz=timezones["jp"],
    ),
    EosLocation(
        abbr="hk",
        name="Hong_Kong",
        cname="香港",
        tz=timezones["hk"],
    ),
    EosLocation(
        abbr="rj",
        name="Rio_de_Janeiro",
        cname="里约热内卢",
        tz=timezones["rj"],
    ),
    EosLocation(
        abbr="unknown",
        name="unknown",
        cname="未知",
        tz=timezones["utc"],
    )
   ]

locations_by_abbr = dict(zip([location.abbr for location in locations], locations))

# since ZoneInfo is hashable, we can use it as key! one to many mapping! among all the tz, the last is the output
locations_from_tz = dict(zip([location.tz for location in locations], locations))
