#!/usr/bin/env python3.10

from zoneinfo import ZoneInfo

timezones = {
    "la": ZoneInfo("America/Los_Angeles"),
    "ny": ZoneInfo("America/New_York"),
    "sh": ZoneInfo("Asia/Shanghai"),
    "xj": ZoneInfo("Asia/Urumqi"),  #   Xinjiang (Urumqi)
    "bl": ZoneInfo("Europe/Berlin"),
    "ld": ZoneInfo("Europe/London"),
    "sy": ZoneInfo("Australia/Sydney"),
    "jp": ZoneInfo("Asia/Tokyo"),
    "hk": ZoneInfo("Asia/Hong_Kong"),
    "rj": ZoneInfo("America/Sao_Paulo"),  # Rio de Janeiro
    "sp": ZoneInfo("America/Sao_Paulo"),  # Sao Paulo
    "utc": ZoneInfo("Etc/UTC"),  # canonical, as default for unknown
}
