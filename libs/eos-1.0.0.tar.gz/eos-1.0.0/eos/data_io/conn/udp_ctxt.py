import contextlib
import socket
from typing import Generator, Optional


@contextlib.contextmanager
def udp_context(
    host: str, port: str, *, timeout: Optional[float] = 5.0
) -> Generator[socket.socket, None, None]:
    """Capture udp context."""

    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    except socket.error:
        raise Exception("Failed to create socket")
    socket.socket.settimeout(s, timeout)
    s.bind((host, int(port)))

    try:
        yield s
    except TimeoutError:
        raise TimeoutError(f"UDP Timeout error: {timeout} seconds")
    except Exception as e:
        raise e
    finally:
        s.close()
