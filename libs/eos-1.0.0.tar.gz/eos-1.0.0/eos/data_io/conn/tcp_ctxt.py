import contextlib
import os

from eos.comm.remote.remote_can_client import RemoteCanClient
from eos.data_io.config import Truck


@contextlib.contextmanager
def tcp_context(
    vehicle: Truck,
    host: str,
    port: str,
    *,
    proxy: str = "",
):
    """Capture udp context."""

    os.environ["http_proxy"] = proxy
    remote_can_client = RemoteCanClient(
        host,
        port,
        truck=vehicle,
    )
    try:
        yield remote_can_client
    except Exception as e:
        raise e
    finally:
        remote_can_client.close()
