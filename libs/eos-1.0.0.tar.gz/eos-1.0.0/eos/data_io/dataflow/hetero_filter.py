import abc
from threading import Event
from dataclasses import dataclass

from .pipeline import Pipeline  # type: ignore
from .pipeline_dq import PipelineDQ  # type: ignore

from typing import Optional, TypeVar, Generic

T_I = TypeVar("T_I")
T_O = TypeVar("T_O")


@dataclass
class HeteroFilter(abc.ABC, Generic[T_I, T_O]):
    def __post_init__(self):
        super().__init__()

    @abc.abstractmethod
    def filter(
        self,
        in_pipeline: PipelineDQ[
            T_I
        ],  # deque[dict[str,str]] for vehicle_interface, Queue[pd.DataFrame] for crunchers
        out_pipeline: Pipeline[T_O],
        start_event: Optional[Event],
        stop_event: Optional[Event],
        interrupt_event: Optional[Event],  # input event
        flash_event: Optional[Event],
        exit_event: Optional[Event],
    ) -> None:
        """
        consume data into the pipeline
        """
        pass
