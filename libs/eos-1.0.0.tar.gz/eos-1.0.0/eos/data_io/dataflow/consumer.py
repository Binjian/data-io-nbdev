import abc
from threading import Event

from dataclasses import dataclass

from typing import Optional, TypeVar, Generic

from .pipeline import Pipeline  # type: ignore

T = TypeVar("T")


@dataclass
class Consumer(abc.ABC, Generic[T]):
    def __post_init__(self):
        super().__init__()

    @abc.abstractmethod
    def consume(
        self,
        pipeline: Pipeline[T],  # T: pd.DataFrame
        start_event: Optional[Event] = None,
        stop_event: Optional[Event] = None,
        interrupt_event: Optional[Event] = None,  # input event
        exit_event: Optional[Event] = None,
        flash_event: Optional[Event] = None,
    ):
        """
        consume data into the pipeline
        """
        pass
