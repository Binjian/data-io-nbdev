import queue
from typing import TypeVar

T = TypeVar("T")


class Pipeline(queue.Queue[T]):
    def get_data(self) -> T:
        """
        Get data from the pipeline
            thread_id: thread id for the thread\

        return:
            data: data from the pipeline
        """
        return self.get()

    def put_data(self, value: T):
        """
        Put data into the pipeline
            value: data to be put into the pipeline
            thread_id: thread id for the thread

        return:
            None
        """

        self.put(value)

    def clear(self):
        """
        clear the pipeline (Queue) as the standard Queue does not have clear() method
        """
        while not self.empty():
            self.get()
