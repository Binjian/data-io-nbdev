class ReadOnlyError(Exception):
    pass


class WriteOnlyError(Exception):
    pass


class TruckIDError(Exception):
    pass
