import signal
from threading import Event


class GracefulKiller:
    exit: Event

    def __init__(self, exit_evt: Event):
        self.exit = exit_evt
        signal.signal(signal.SIGINT, self.exit_gracefully)
        signal.signal(signal.SIGTERM, self.exit_gracefully)
        signal.signal(signal.SIGHUP, self.exit_gracefully)

    def exit_gracefully(self, signum, frame):
        print(f"Received signal {signum} on frame {frame}")
        if not self.exit.is_set():
            print(f"set exit event")
            self.exit.set()
        else:
            print(f"exit event already set")
