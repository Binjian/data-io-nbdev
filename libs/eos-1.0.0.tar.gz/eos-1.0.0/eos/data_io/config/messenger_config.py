from collections import namedtuple

CANMessenger = namedtuple(
    "CANMessenger",
    [
        "server_name",  # name of the can server
        "host",  # url for the can server
        "port",  # port for the can server
        "protocol",  # protocol for the can server, for now either "udp" or "tcp"
    ],  # "protocol" is used to differentiate between the two modes of communication "cloud" or "local"
)
TripMessenger = namedtuple(
    "TripMessenger",
    [
        "server_name",  # name of the trip contol hmi server
        "host",  # url for the trip server
        "port",  # port for the trip server
        "protocol",  # port for the trip server
    ],
)
can_server_list = [
    CANMessenger(
        server_name="can_intra",  # name of the can server
        host="10.0.64.78",  # url for the database server
        port="5000",  # port for the database server
        protocol="tcp",
    ),
    CANMessenger(
        server_name="can_cloud",  # name of the database
        host="10.10.0.6",  # url for the database server
        port="30865",  # port for the database server
        protocol="tcp",
    ),
    CANMessenger(
        server_name="can_cloud_svc",  # name of the database
        host="remotecan.veos",  # url for the database server
        port="5000",  # port for the database server
        protocol="tcp",
    ),
    CANMessenger(
        server_name="can_udp_svc",  # name of the database
        host="127.0.0.1",  # url for the database server
        port="8002",  # port for the database server
        protocol="udp",
    ),
]

can_servers_by_name = dict(
    zip([srv.server_name for srv in can_server_list], can_server_list)
)
can_servers_by_host = dict(zip([srv.host for srv in can_server_list], can_server_list))

trip_server_list = [
    TripMessenger(
        server_name="rocket_intra",  # name of the database
        host="10.0.64.78",  # url for the database server
        port="9876",  # port for the database server
        protocol="tcp",
    ),
    TripMessenger(
        server_name="rocket_cloud",  # name of the database
        host="10.0.64.122",  # url for the database server
        port="9876",  # port for the database server
        protocol="tcp",
    ),
    TripMessenger(
        server_name="rocket_cluster",  # name of the database
        host="10.10.0.13",  # url for the database server
        port="9876",  # port for the database server
        protocol="tcp",
    ),
    TripMessenger(
        server_name="local_udp",  # name of the database
        host="127.0.0.1",  # url for the database server
        port='8002',  # port for the database server
        protocol="udp",
    ),
]
trip_servers_by_name = dict(
    zip([srv.server_name for srv in trip_server_list], trip_server_list)
)
trip_servers_by_host = dict(
    zip([srv.host for srv in trip_server_list], trip_server_list)
)
