from .ddpg import DDPG

__all__ = ["DDPG"]
