from collections import UserDict
from dataclasses import dataclass
from typing import Optional

# from requests.exceptions import (
#     ConnectionError,
#     HTTPError,
#     InvalidJSONError,
#     ReadTimeout,
#     RequestException,
#     Timeout,
# )


@dataclass(kw_only=True)
class RemoteCanException(Exception):
    """Base class for all remote CAN exceptions."""

    err_code: Optional[int] = 1001  # default exception is unknown connection error
    extra_msg: Optional[str] = None
    codes: Optional[UserDict] = None  # = field(default_factory=UserDict)

    def __post_init__(self):
        self.codes = UserDict(  # class attribute, if not given use the default
            {
                0: "success",
                1: "client_cannot_connect_to_server",
                2: "ai_mode_shutdown",
                1000: "network_connection_error",
                1001: "network_unknown_error",
                1002: "network_timeout",
                -1: "tsp_internal_error",
                202: "tsp_no_API_exist",
                206: "tsp_parameter_wrong",
                301: "tsp_out_of_time",
                302: "tsp_command_execute_error",
                303: "tsp_car_not_registered",
                304: "tsp_car_offline",
                310: "tsp_internal_exception_error",
                311: "tsp_tbox_returned_error",
                3000: "tsp_return_result_is_not_dictionary",
                3001: "tsp_return_result_has_no_oss_link",
                2000: "uds_version_failed",
                2001: "ab_torque_switch_failed",
                2002: "oss_data_not_enough",
                2003: "torque_shape_error",
                2004: "torque_range_error",
                2005: "remote_can_unknown_format",
            }
        )
        # print(
        #     f"{{\'header\': \'err_code\': \'{self.err_code}\', "
        #     f"\'msg\': \'{self.codes[self.err_code]}\', "
        #     f"\'extra_msg\': \'{self.extra_msg}\'}}"
        # )
