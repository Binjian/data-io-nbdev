#!/usr/bin/env python3

import tbox_sim

if __name__ == "__main__":
    # args = parse_arg()
    value = [99.0] * 21 * 17
    tbox_sim.set_tbox_sim_path("/home/user/work/045b_demo/tbox-simulator")
    tbox_sim.send_float_array("TQD_trqTrqSetNormal_MAP_v", value)
