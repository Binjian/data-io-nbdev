import json
import socket
import time

from rocketmq.client import PullConsumer


def validate_params(json_dic, start_time, need_vin=True):
    params = None
    if isinstance(json_dic, str):
        params = json.loads(json_dic)
    elif isinstance(json_dic, dict):
        params = json_dic
    else:
        print("unaccaptable format, json is:", json_dic, type(json_dic))

        return (
            params,
            {
                "success": False,
                "result": {},
                "reason": "unaccaptable format, json is type of :"
                + str(type(json_dic)),
            },
        )
        False

    if need_vin and "vin" not in params:
        return (
            params,
            {
                "success": False,
                "result": {},
                "reason": 'parameter "vin" required but not gived',
            },
            False,
        )
    return params, {}, True


def command_handle(json_dic: dict):
    if json_dic == None:
        return {"error": "json is None"}, False

    start_time = time.time()
    params, json_ret, is_valide = validate_params(json_dic, start_time, True)
    if is_valide == False:
        return False

    # start,algorithm care only this block<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    data_dic = {"algorithm_id": 1, "vin": params["vin"]}
    if "name" in params:
        data_dic["driver_id"] = params["name"]
    else:
        data_dic["driver_id"] = ""
    if "code" in params:
        handle_msg(data_dic, params["code"])
    # end>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    return True


def send_data(data):
    udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    send_addr = ("0.0.0.0", 8012)

    data = json.dumps(data)
    udp_socket.sendto(data.encode("utf-8"), send_addr)


def handle_msg(data_dic: dict, code: int):
    code_start = 1
    code_valid_stop = 2
    code_invalid_stop = 3
    code_ready = 4

    if code == code_valid_stop:
        data_dic["message"] = "valid_end"
    elif code == code_invalid_stop:
        data_dic["message"] = "invalid_end"
    elif code == code_start:
        data_dic["message"] = "start"

    send_data(data_dic)
    print(data_dic)


import address_manager

if __name__ == "__main__":
    __rocket_url = address_manager.get_rocket_address()
    topic = "drivecircle_action"

    # from rocketmq.client import PushConsumer

    # def callback(msg):
    #     print(msg.body)
    #     sended = command_handle(json.loads(msg.body))

    # consumer = PushConsumer('PID_XXX', orderly=True)
    # consumer.set_namesrv_addr(__rocket_url)
    # consumer.subscribe(topic, callback)
    # consumer.start()

    # while True:
    #     print('sleep')
    #     time.sleep(3600)

    # consumer.shutdown()
    ###############################=================================
    from ClearablePullConsumer import ClearablePullConsumer

    circle_consumer = ClearablePullConsumer("CID_XXX")
    circle_consumer.set_namesrv_addr(__rocket_url)
    circle_consumer.start()

    circle_consumer.clear_history(topic)

    while True:
        broker_msgs = circle_consumer.pull(topic)
        for msg in broker_msgs:
            print(msg)
            sended = command_handle(json.loads(msg.body))

    consumer.shutdown()
