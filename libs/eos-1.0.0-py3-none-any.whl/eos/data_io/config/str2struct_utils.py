# conversion from str to internal data structure in data_io/config/vehicle, driver, truck, db_config
import re
from typing import Union

from .drivers import RE_DRIVER, Driver, drivers_by_id  # type: ignore
from .messenger_config import (
    CANMessenger,
    TripMessenger,  # type: ignore
    can_servers_by_host,
    can_servers_by_name,
    trip_servers_by_host,
    trip_servers_by_name,
)
from .vehicles import (
    RE_VIN,
    TruckInCloud,
    TruckInField,  # type: ignore
    trucks_by_id,
    trucks_by_vin,
)


# vehicle_str: str = 'HMZABAAH7MF011058'  # "VB7",
def str_to_truck(truck_str: str) -> Union[TruckInCloud, TruckInField]:
    p = re.compile(RE_VIN)
    if p.match(truck_str):
        try:
            truck: Union[TruckInCloud, TruckInField] = trucks_by_vin[truck_str]
        except KeyError:
            raise KeyError(f"No Truck with VIN {truck_str}")
    else:
        try:
            truck: Union[TruckInCloud, TruckInField] = trucks_by_id.get(truck_str)  # type: ignore
        except KeyError:
            raise KeyError(f"No Truck with ID {truck_str}")

    return truck


# driver_str: str = 'zheng-longfei'
def str_to_driver(driver_str: str) -> Driver:
    p = re.compile(RE_DRIVER)
    assert p.match(driver_str), f"Invalid driver string: {driver_str}"
    try:
        driver: Driver = drivers_by_id[driver_str]
    except KeyError:
        raise KeyError(f"No Driver with ID {driver_str}")

    return driver


def str_to_can_server(can_server_str: str) -> CANMessenger:
    try:
        can_server = can_servers_by_name[can_server_str]
    except KeyError:
        try:
            can_server = can_servers_by_host[can_server_str.split(":")[0]]
        except KeyError:
            raise KeyError(f"CAN server not found: {can_server_str}!")
    assert type(can_server) is CANMessenger, f"Wrong type for can_server {can_server}!"
    return can_server


def str_to_trip_server(trip_server_str: str) -> TripMessenger:
    try:
        trip_server = trip_servers_by_name[trip_server_str]
    except KeyError:
        try:
            trip_server = trip_servers_by_host[trip_server_str.split(":")[0]]
        except KeyError:
            raise KeyError(f"Trip server not found: {trip_server_str}!")

    assert (
        type(trip_server) is TripMessenger
    ), f"Wrong type for trip_server {trip_server}!"
    return trip_server
