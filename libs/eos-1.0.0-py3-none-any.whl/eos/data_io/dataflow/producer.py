import abc
from threading import Event
from dataclasses import dataclass

from .pipeline import Pipeline  # type: ignore
from .pipeline_dq import PipelineDQ  # type: ignore

from typing import Optional, TypeVar, Generic

T_RAW = TypeVar("T_RAW")
T_HMI = TypeVar("T_HMI")


@dataclass
class Producer(abc.ABC, Generic[T_RAW, T_HMI]):
    def __post_init__(self):
        super().__init__()

    @abc.abstractmethod
    def produce(
        self,
        raw_pipeline: PipelineDQ[
            T_RAW
        ],  # Raw pipeline is deque to keep data fresh and ignore stale data, such as one with dict[str,str]
        hmi_pipeline: Optional[
            Pipeline[T_HMI]
        ] = None,  # HMI pipeline is Queue, such as one with str
        exit_event: Optional[Event] = None,
    ):
        """
        Produce data into the pipeline
        """
        pass
