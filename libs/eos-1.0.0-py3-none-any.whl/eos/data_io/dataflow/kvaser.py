import json
from threading import Event, current_thread
from typing import Optional, Tuple, cast
from dataclasses import dataclass

import pandas as pd
from .consumer import Consumer  # type: ignore
from .pipeline import Pipeline  # type: ignore
from .pipeline_dq import PipelineDQ  # type: ignore
from .producer import Producer  # type: ignore
from .vehicle_interface import VehicleInterface  # type: ignore

from eos.comm import TBoxCanException, kvaser_send_float_array
from eos.data_io.conn import udp_context
from eos.data_io.eos_struct import MotionPower, RawType, KvaserType
from eos.data_io.config import CANMessenger, can_servers_by_name, TruckInField


@dataclass
class Kvaser(VehicleInterface):
    """
    Kvaser is local vehicle interface with Producer(get vehicle status) and Consumer(flasher)
    """

    truck: TruckInField
    can_server: CANMessenger = can_servers_by_name["can_udp_svc"]

    def __post_init__(self):
        super().__post_init__()
        self.logger.info("Kvaser initialized")

    def __str__(self):
        return "kvaser"

    def flash_vehicle(self, torque_table: pd.DataFrame) -> None:
        try:
            kvaser_send_float_array(torque_table, sw_diff=True)
        except TBoxCanException as exc:
            raise exc
        except Exception as exc:
            raise exc

        self.logger.info(
            f"{{'header': 'Done with flashing table'}}",
            extra=self.dict_logger,
        )

    def init_internal_pipelines(
        self,
    ) -> Tuple[
        PipelineDQ[RawType], Pipeline[str]
    ]:  # Tuple[PipelineDQ[dict[str,Union[str,list[str]]]], Pipeline[str]]
        raw_pipeline = PipelineDQ[RawType](maxlen=1)
        hmi_pipeline = Pipeline[str](maxsize=1)
        return raw_pipeline, hmi_pipeline

    def produce(
        self,
        raw_pipeline: PipelineDQ[RawType],  # PipelineDQ[dict[str, str]],
        hmi_pipeline: Optional[Pipeline[str]] = None,
        exit_event: Optional[Event] = None,
    ):
        thread = current_thread()
        thread.name = "kvaser_capture"
        logger_kvaser_get = self.logger.getChild("kvaser_capture")
        logger_kvaser_get.propagate = True
        logger_kvaser_get.info(
            f"{{'header': 'kvaser capture thread start!'}}",
            extra=self.dict_logger,
        )

        with udp_context(self.can_server.host, self.can_server.port) as s:
            # self.logger.info('Data received!!!', extra=self.dict_logger)
            while not exit_event.is_set():
                try:
                    can_data, addr = s.recvfrom(2048)
                    pop_data = json.loads(can_data)
                except TypeError:
                    raise TypeError("udp sending wrong data type!")
                except Exception as exc:
                    logger_kvaser_get.error(
                        f"{{'header': 'udp reception error', " 
                        f"'exception': '{exc}'}}"
                    )
                    raise exc
                for key, value in pop_data.items():
                    if key == "status":  # state machine chores
                        assert (
                            type(value) is str
                        ), "udp sending wrong data type of status!"
                        hmi_pipeline.put_data(value)
                    elif key == "data":
                        assert (
                            type(value) is dict
                        ), "udp sending wrong data type of data!"
                        raw_pipeline.put_data(value)
                    else:
                        logger_kvaser_get.warning(
                            f"{{'header': 'udp sending message with key: {key}; value: {value}'}}"
                        )

                        break
                if (
                    key == "status" and value == "exit"
                ):  # exit thread and program, if earlier than the exit event
                    break

            # exit the thread
            logger_kvaser_get.info(
                f"{{'header': 'kvaser_capture dies!!!'}}", extra=self.dict_logger
            )

    def filter(
        self,
        in_pipeline: PipelineDQ[RawType],  # PipelineDQ[dict[str, str]],
        out_pipeline: Pipeline[pd.DataFrame],
        start_event: Optional[Event],
        stop_event: Optional[Event],
        interrupt_event: Optional[Event],  # input event
        flash_event: Optional[
            Event
        ],  # input & output event, maybe unnecessary for kvaser
        exit_event: Optional[Event],  # input event
    ) -> None:
        thread = current_thread()
        thread.name = "kvaser_filter"
        logger_kvaser_out = self.logger.getChild("data_transform")
        logger_kvaser_out.propagate = True
        motion_power_t: list[MotionPower] = []
        logger_kvaser_out.info("{{'header': 'kvaser data transform thread start'}}", extra=self.dict_logger)

        while not exit_event.is_set():
            #  always get data from the pipeline if available, forwarding outward depends on the HMI status
            try:
                data: KvaserType = cast(
                    KvaserType, in_pipeline.get_data()
                )  # non-blocking, get the most recent data, cast is to sooth mypy

            except IndexError:
                continue  # empty deque

            # logger_kvaser_out.info("{{'header': 'kvaser get data'}}", extra=self.dict_logger)

            if start_event.is_set():  # starts episode
                try:
                    timestep = pd.Timestamp.now(tz=self.truck.site.tz)
                    velocity = float(data["velocity"])
                    pedal = float(data["pedal"])
                    brake = float(data["brake_pressure"])
                    current = float(data["A"])
                    voltage = float(data["V"])

                    motion_power = MotionPower(
                        timestep,
                        velocity,
                        pedal,
                        brake,
                        current,
                        voltage,
                    )
                    # 3 +2 : im 5

                    motion_power_t.append(
                        motion_power
                    )  # obs_reward [timestep, speed, pedal, brake, current, voltage]

                    if len(motion_power_t) == self.truck.observation_length:
                        df_motion_power = pd.DataFrame(
                            motion_power_t,
                            columns=[
                                "timestep",
                                "velocity",
                                "thrust",
                                "brake",
                                "current",
                                "voltage",
                            ],
                        )
                        # df_motion_power.set_index('timestamp', inplace=True)
                        df_motion_power.columns.name = "qtuple"

                        out_pipeline.put_data(df_motion_power)
                        logger_kvaser_out.info(
                            f"{{'header': 'convert one dataframe and wait.'}}",
                            extra=self.dict_logger,
                        )
                        flash_event.wait()  # wait for cruncher to consume and flashing to finish
                        flash_event.clear()  # clear the flash event here as the first waiter
                        logger_kvaser_out.info(
                            f"{{'header': 'wake up after flashing'}}",
                            extra=self.dict_logger,
                        )
                        # for kvaser the parameter is configured for waiting,
                        # maybe the event is not necessary, for cloud interface the flash event is necessary
                        observe_queue_size = out_pipeline.qsize()
                        if observe_queue_size != 0:
                            raise ValueError(
                                f"observe pipeline queue size: {observe_queue_size}, "
                                f"must be zero, if cruncher has consumed"
                            )
                        motion_power_t = []
                except Exception as exc:
                    logger_kvaser_out.info(
                        f"{{'header': 'kvaser get signal error',"
                        f"'exception': '{exc}'}}",
                        # f"Valid episode, Reset data capturing to stop after 3 seconds!",
                        extra=self.dict_logger,
                    )
                    break
            elif interrupt_event.is_set() or stop_event.is_set():  # interrupt episode
                motion_power_t = []  # clean up list of motion power states

        # exit the thread
        logger_kvaser_out.info(
            f"{{'header': 'data_transform dies!!!'}}", extra=self.dict_logger
        )
