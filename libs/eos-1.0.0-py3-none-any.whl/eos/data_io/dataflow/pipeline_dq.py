from collections import deque

from typing import TypeVar

T = TypeVar("T")


class PipelineDQ(deque[T]):
    def get_data(self) -> T:
        """
        Get data from the pipeline
            thread_id: thread id for the thread\

        return:
            data: data from the pipeline
        """
        return self.pop()

    def put_data(self, value: T):
        """
        Put data into the pipeline
            value: data to be put into the pipeline
            thread_id: thread id for the thread

        return:
            None
        """

        self.append(value)

    def clear(self):
        """
        clear the pipeline (Deque)
        """
        self.clear()
